window.onload= function () {
  var courseInfo=new Array(); //定义一个课程信息的数组存放课程对象
  var obj1={name:"html/css",imgSrc:"img/Html5course.jpg",commentScore:"9.0",focusNum:"8888"};
  var obj2={name:"JavaScript",imgSrc:"img/js.jpg",commentScore:"8.0",focusNum:"7777"};
  var obj3={name:"css3",imgSrc:"img/css3.png",commentScore:"7.0",focusNum:"6666"};
  var obj4={name:"html/css",imgSrc:"img/Html5course.jpg",commentScore:"9.0",focusNum:"8888"};
  var obj5={name:"JavaScript",imgSrc:"img/js.jpg",commentScore:"8.0",focusNum:"7777"};
  var obj6={name:"css3",imgSrc:"img/css3.png",commentScore:"7.0",focusNum:"6666"};
  var obj7={name:"html/css",imgSrc:"img/Html5course.jpg",commentScore:"9.0",focusNum:"8888"};
  var obj8={name:"JavaScript",imgSrc:"img/js.jpg",commentScore:"8.0",focusNum:"7777"};
  var obj9={name:"css3",imgSrc:"img/css3.png",commentScore:"7.0",focusNum:"6666"};
  courseInfo.push(obj1,obj2,obj3,obj4,obj5,obj6,obj7,obj8,obj9); //将每一个课程对象放置到数组中

  var oView=document.getElementById("view");//获取存放页面的内容区
  var courseLen=courseInfo.length; //获取当前所有的课程的长度
  var ViewNum=Math.ceil(courseLen/6); //每页6个课程，计算出需要几个页面存放课程
  var order=0; //记录当前输出课程到达的顺序
  var pageNum=0;//翻页的页面顺序
  for(var i=0;i<ViewNum;i++){ //循环将所有的课程打印到对应的显示页面上
      var oViewSon=document.createElement("div");//创建装课程的div
      oViewSon.className="view-son";
      oViewSon.style.zIndex=ViewNum-i;//设置堆叠顺序,把第一页显示在最上面
      if(courseLen>6){ //打印出当前课程长度还大于6的
          for(var j=order;j<order+6;j++){
              CreateCourse(oViewSon,courseInfo,j);
          }
          courseLen-=6;//计算剩下的课程长度
          order+=6;//已经输出了6个课程
      }else {
          for(var k=order;k<order+courseLen;k++){//打印出剩余课程数<=6的
              CreateCourse(oViewSon,courseInfo,k);
          }
      }
      oView.appendChild(oViewSon);//在页面中添加该页面的课程
  }
  if(ViewNum>1){
      createPage();//调用创建翻页按钮的函数
  }
  function CreateCourse(vSon,cInfo,index){ //创建具体的课程信息页面
      var oCourse1=document.createElement("div");
      var oImg=document.createElement("img");
      var oLab1=document.createElement("label");
      var oLab2=document.createElement("label");
      oCourse1.className="view-son-course";
      oImg.src=cInfo[index].imgSrc;
      oImg.className="view-son-img";
      oLab1.innerText="评分:"+cInfo[index].commentScore;
      oLab1.className="view-son-lab1";
      oLab2.innerText=cInfo[index].focusNum+"人关注";
      oLab2.className="view-son-lab2";
      oCourse1.appendChild(oImg);
      oCourse1.appendChild(oLab1);
      oCourse1.appendChild(oLab2);
      vSon.appendChild(oCourse1);
  }
  function createPage(){//创建动态的按钮
      var oPage=document.createElement("div");//创建放上一页、1、2、3……下一页 页面按钮的div
      var oPrev=document.createElement("button");//创建上一页按钮
      var oNext=document.createElement("button");//创建下一页按钮
      oPage.className="view-page";
      oPrev.innerText="上一页";
      oNext.innerText="下一页";
      oPrev.onclick= function () {
          pageNum--;
          if(pageNum<0){
              pageNum=0;  //边界判定，当索引为0，即页数为第一页，不能再向下翻页
          }else{
              showCourse();
          }
      };
      oNext.onclick= function () {
          pageNum++;
          if(pageNum>ViewNum-1){
              pageNum=ViewNum-1;  //边界判定，当大于最多的显示区的时候，不能再向上翻页
          }else{
              showCourse();
          }
      };
      oPage.appendChild(oPrev);//在页码div中添加上一页按钮
      for(var i=0;i<ViewNum;i++){
          var oPageBut=document.createElement("div");//创建页码按钮（即 1、2、3……）
          oPageBut.innerText=i+1;
          oPageBut.className="view-page-but";
          oPageBut.index=i;//i存储在index来指代第几页
          oPageBut.onclick= function (e) {
              pageNum= e.target.index;//e.target指的是触发事件的当前对象
              showCourse();
          };
          oPage.appendChild(oPageBut);//在页码div中添加1、2、3……页码按钮
      }
      oPage.appendChild(oNext);//在页码div中添加下一页按钮
      oView.appendChild(oPage);//在页面中添加装有所有页码按钮的div
  }
  function showCourse(){//点击对应的按钮，显示对应的课程
      var tem=oView.children;//获取oView的所有子元素，包括ViewNum 个 oViewSon（放课程的div）和一个oPage（放页码按钮的div）
      var len=tem.length;
	//  console.log(len); 9个课程的话，len = 3。
      for(var i=0;i<len;i++){
          if(tem[i].className=="view-son"){//先把 oViewSon（放课程的div）全部隐藏起来
              tem[i].style.display="none"; 
          }
      }
      tem[pageNum].style.display="block";//再把pageNum这个页码下的 oViewSon（放课程的div） 显示出来。
  }
};