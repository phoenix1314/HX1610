
/***点击弹出对应菜单内容***/
/*
function show(a){//声明函数   形参  传递参数
	console.log(a);
	// var oLi1 = document.getElementById('li1');
	// alert(a == oLi1);
	alert(a.innerText);
}
*/

// var ary = [1,3,5];
// alert(ary[2]);


/****点击变字体颜色***/
function show(b){//声明函数   形参  传递参数
var  aLi = document.getElementsByTagName("li");//DOM   文档对象模型
//3   [0][1][2]
for(var i=0;i<aLi.length;i++){
	aLi[i].style.color = "black";
	//aLi[0].style.color = "black";
	//aLi[1].style.color = "black";
	//aLi[2].style.color = "black";
}
// console.log(aLi);
// console.log(b);	
b.style.color = "red";
// b.style.backgroundColor = "black";
}



// function show1(){
// 	alert("数学");
// }
// function show2(){
// 	alert("English");

// }